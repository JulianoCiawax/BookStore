<?php
include_once("header.php");
?>
<title>Sobre</title>
<style>
body {
    color: #f5f6f7;
}

p {
    font-size: 16px;
}

.margin {
    margin-bottom: 45px;
}

.bg-1 {
    background-color: #1abc9c;
    color: #ffffff;
}

.container-fluid {
    padding-top: 70px;
    padding-bottom: 70px;
}
</style>
</head>

<body>
    <?php
include_once("menu.php");
?>
    <div class="container-fluid bg-1 text-center">
        <h3 class="margin">Quem somos?</h3>
        <img src="book.png" class="img-responsive img-circle margin" style="display:inline" alt="Book" width="150"
            height="150">
        <h3>Sistema de escola criado para o projeto final de Banco de Dados.</h3>
        <h4>Alunos: Juliano Carlos da Costa, Lucas Rodrigo Rosa</h4>
    </div>
</body>

</html>